export default function AuthLayout({ children }) {
    return <>{children}</>;
}
